function przyblizenie() {
    var element = document.getElementById("nowysezonjestSlaby");
    element.animate(
      { fontSize: '500px' },
      {
        duration: 500,
        easing: 'ease-in-out',
        fill: 'forwards'
      }
      
    );
  }

function oddalenie() {
    var element = document.getElementById("nowysezonjestSlaby");
    element.animate(
      { fontSize: '20px' },
      {
        duration: 500,
        easing: 'ease-in-out',
        fill: 'forwards'
      }
    );
}

var disco = document.getElementById("nowysezonjestSlaby");
var muzyka = new Audio('279851319_5221972707897718_2672230996709737152_n.mp3');

disco.addEventListener("mouseover", gra, false);
disco.addEventListener("mouseout", niegra, false);

function gra() {
   muzyka.play();
}

function niegra() {
   muzyka.pause();
}




var rainbowInterval;

function atakEpilepsji() {
    czasZmiany = setInterval(zmianiaKoloru, 10);
}

function szpitalpoataku() {
    clearInterval(czasZmiany);
    
    document.body.style.backgroundColor = "gray";
}

function zmianiaKoloru() {
    
var wcalenieEpilepsja = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"];

    
var randomowa = Math.floor(Math.random() * wcalenieEpilepsja.length);

    
    document.body.style.backgroundColor = wcalenieEpilepsja[randomowa];
}

function odjazd() {
    var zdjecie = document.getElementById("doprawej");

    
    var pozycja = zdjecie.offsetLeft + 1000;

    
    zdjecie.animate(
      { left: pozycja + 'px' },
      {
        duration: 100, 
        easing: 'ease-in-out'
      }
    );
  }